from setuptools import setup
setup(
    name="PackageHimaloy",
    version="0.1.0",
    description="This is Desc",
    author="Himaloy",
    packages=['PackageHimaloy'],
    install_requires=[]
)