def createfile(filename, text):
    with open(f'D://Mydesktop/{filename}.txt', 'w') as fh:
        for i in range(1):
            fh.write(text)

class my_dictionary(dict):
    def add(self, key, value):
        self[value] = key