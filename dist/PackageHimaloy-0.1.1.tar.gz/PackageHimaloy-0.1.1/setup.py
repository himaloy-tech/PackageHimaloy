from setuptools import setup
from PackageHimaloy import *
setup(
    name="PackageHimaloy",
    version="0.1.1",
    description="This is Desc",
    author="Himaloy",
    packages=['PackageHimaloy'],
    install_requires=[]
)